// Simple background script for Wisor extension
console.log('Wisor extension loaded');